document.querySelector("form").addEventListener("submit", function(event) {
    event.preventDefault();

    let studentId = document.getElementById("studentId").value;
    let studentName = document.getElementById("studentName").value;
    let date = document.getElementById("dob").value;
    let tel = document.getElementById("phone").value;
    
    let parentName = document.getElementById("parentName").value; 
    let tel1 = document.getElementById("phone1").value;
    let address = document.getElementById("address").value;

    localStorage.setItem("studentId", studentId);
    localStorage.setItem("studentName", studentName);
    localStorage.setItem("dob", date);
    localStorage.setItem("phone", tel);
    localStorage.setItem("parentName", parentName);
    localStorage.setItem("phone1", tel1);
    localStorage.setItem("address", address);

    let currentUser = JSON.parse(localStorage.getItem("currentUser")) || {};
    currentUser.id = studentId;
    currentUser.name = studentName;
    currentUser.birthdate = date; 
    currentUser.phone = tel;
    currentUser.parentName = parentName; 
    currentUser.phone1 = tel1; 
    currentUser.address = address;

    localStorage.setItem("currentUser", JSON.stringify(currentUser));

    let students = JSON.parse(localStorage.getItem("students")) || [];

    let studentIndex = students.findIndex(s => 
        (studentId && s.id === studentId) || 
        (currentUser.email && s.email === currentUser.email)
    );

    if (studentIndex !== -1) {
        students[studentIndex].id = studentId;
        students[studentIndex].name = studentName;
        students[studentIndex].birthdate = date;
        students[studentIndex].phone = tel;
        students[studentIndex].parentName = parentName;
        students[studentIndex].phone1 = tel1;
        students[studentIndex].address = address;
    } else {
        students.push(currentUser);
    }

    localStorage.setItem("students", JSON.stringify(students));

    alert("Registration Successful! Back to Dashboard.");
    window.location.href = "user_dashboard.html";
});